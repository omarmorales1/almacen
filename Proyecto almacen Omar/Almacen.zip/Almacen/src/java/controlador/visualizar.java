package controlador;

import java.io.IOException;
import java.util.ArrayList;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import modelo.ConexionBD;


/**
 *
 * @author Carlos Omar
 */

public class visualizar {

    private ArrayList<requisiciones> lista= new ArrayList<requisiciones>(){};
    
    
    public visualizar() {
    }
    
    public void validar() throws IOException {
        
        try{
            
        FacesContext context = javax.faces.context.FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
        String user=session.getAttribute("usuario").toString();
        
      /* if("".equals(user)||user==null){
            ExternalContext contexto = FacesContext.getCurrentInstance().getExternalContext();
            contexto.redirect("index.xhtml");
       }else{
           
       }*/
        }catch(Throwable e){
           
        }
        
    }
    
  /*  public void permission() throws IOException {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        if(facesContext.getExternalContext().getSession() == false) {
            System.out.println("*** The user has no permission to visit this page. *** ");
            ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();
            context.redirect("login.xhtml");
        } else {
            System.out.println("*** The session is still active. User is logged in. *** ");
        }
    }
    */
    public void cargarLista(){
        
        try{
            
        ConexionBD conexion = new ConexionBD();
        
        ArrayList resultado=conexion.ejecutarSelectAll("requisiciones");
        
        if(resultado!=null){

            for(int i=0; i<resultado.size(); i++){
                
                ArrayList vRowTemp = (ArrayList)resultado.get(i);
                requisiciones requisiciones = new requisiciones();
               
                requisiciones.setId(vRowTemp.get(0).toString());
                requisiciones.setNombreProducto(vRowTemp.get(1).toString());
                requisiciones.setModeloProducto(vRowTemp.get(2).toString());
                requisiciones.setCantidadProducto(vRowTemp.get(3).toString());
                requisiciones.setMarcaProducto(vRowTemp.get(4).toString());
                requisiciones.setFechaPedido(vRowTemp.get(5).toString());
                
                this.lista.add(requisiciones);
            }   

        }
        
       }catch(Exception e){
           
            System.out.println(e);
            
       }
    }

    public ArrayList<requisiciones> getLista() {
        return lista;
    }

    public void setLista(ArrayList<requisiciones> lista) {
        this.lista = lista;
    }
    
    
}
