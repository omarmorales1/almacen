

package controlador;

import java.sql.PreparedStatement;
import java.util.Date;
import java.util.regex.Pattern;
import modelo.ConexionBD;

/**
 *
 * @author Carlos Omar
 */
public class registroCompras {

    /**
     * Creates a new instance of registroCompras
     */
    public registroCompras() {
    }
    
    private String usuario=null;
    private String password;
    private String nombre=null;
    private String direccion=null;
    private Date fechaNacimiento;
    private String telefono;
    private String tipo;

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public void registro() throws Exception{
        ConexionBD conexion =new ConexionBD();
        String tabla="usuario";
        String datos=usuario+"|"+password+"|"+nombre+"|"+direccion+"|"+tipo+"|"+fechaNacimiento+"|"+telefono;
        
        try{
        conexion.conectarMySQL();
        PreparedStatement stmt = null;//metodo
        String[] data = datos.split(Pattern.quote("|"));
        String signos="";
            for (int i = 0; i < data.length; i++) {
            signos+=",?";
            }
            String query = "INSERT INTO "+ tabla+ " VALUES(null"+
            signos        
            +")";
            stmt = conexion.conn.prepareStatement(query);
            java.sql.Date fechaMysql=new java.sql.Date(fechaNacimiento.getTime());
            stmt.setString(1,usuario);
            stmt.setString(2,password);
            stmt.setString(3,nombre);
            stmt.setString(4,direccion);
            stmt.setDate(5, fechaMysql);
            stmt.setString(6,telefono);
            stmt.setString(7,tipo);
            System.out.println(query+"-----------"+stmt);
          
        stmt.executeUpdate();
        conexion.desconectar();
      
        }catch(Throwable e){
            System.err.println(e);
        }
        
    }
}
