
package controlador;

import java.sql.PreparedStatement;
import java.util.Date;
import java.util.regex.Pattern;
import modelo.ConexionBD;

/**
 *
 * @author Carlos Omar
 */
public class pedidos {
    
    

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getPrecioIVA() {
        return precioIVA;
    }

    public void setPrecioIVA(String precioIVA) {
        this.precioIVA = precioIVA;
    }

    public String getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(String precioTotal) {
        this.precioTotal = precioTotal;
    }

    public String getProovedor() {
        return proovedor;
    }

    public void setProovedor(String proovedor) {
        this.proovedor = proovedor;
    }

    public String getProducto() {
        return idproducto;
    }

    public void setProducto(String producto) {
        this.idproducto = producto;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public void setUnidadMedida(String unidadMedida) {
        this.unidadMedida = unidadMedida;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getNumDeSerie() {
        return numDeSerie;
    }

    public void setNumDeSerie(String numDeSerie) {
        this.numDeSerie = numDeSerie;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    private String precio;
    private String precioIVA;
    private String precioTotal;
    private String proovedor;
    private String idproducto;

    public String getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(String idproducto) {
        this.idproducto = idproducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    private String nombre;
    private String marca;
    private String modelo;
    private String unidadMedida;
    private String cantidad;
    private String numDeSerie;
    private String descripcion;
    private Date fecha;
    
    public pedidos() {
    }
    
    public void registrar(){
        
        String tabla="pedido";
        String datos=fecha+"|"+precio+"|"+precioIVA+"|"+precioTotal+"|"+proovedor+"|"+idproducto;
        
        String tabla2="producto";
        String datos2=nombre+"|"+marca+"|"+modelo+"|"+precioTotal+"|"+unidadMedida+"|"+cantidad+"|"+numDeSerie+"|"+descripcion;
        /*
        try{
        ConexionBD conexion =new ConexionBD();
        conexion.conectarMySQL();
        PreparedStatement stmt = null;//metodo
        String[] data = datos.split(Pattern.quote("|"));
        String signos="";
            for (int i = 0; i < data.length; i++) {
            signos+=",?";
            }
            String query = "INSERT INTO "+ tabla+ " VALUES(null"+
            signos        
            +")";
            stmt = conexion.conn.prepareStatement(query);
            java.sql.Date fechaMysql=new java.sql.Date(fechaNacimiento.getTime());
            stmt.setString(1,usuario);
            stmt.setString(2,password);
            stmt.setString(3,nombre);
            stmt.setString(4,direccion);
            stmt.setDate(5, fechaMysql);
            stmt.setString(6,telefono);
            stmt.setString(7,tipo);
            System.out.println(query+"-----------"+stmt);
          
        stmt.executeUpdate();
        conexion.desconectar();
      
        }catch(Throwable e){
            System.err.println(e);
        }*/
    }
}
