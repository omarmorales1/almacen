
package controlador;

import modelo.proovedoresLista;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.regex.Pattern;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import modelo.ConexionBD;

/**
 *
 * @author Carlos Omar
 */
public class proovedores {

    private String nombre;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    private String direccion;
    private String telefono;
    private ArrayList<proovedoresLista> lista= new ArrayList<proovedoresLista>(){};

    public ArrayList<proovedoresLista> getLista() {
        return lista;
    }

    public void setLista(ArrayList<proovedoresLista> lista) {
        this.lista = lista;
    }
    
    public proovedores() {
    }
    
    
    
    public void cargarListas(){
        
        try{
            
        ConexionBD conexion = new ConexionBD();
        
        ArrayList resultado=conexion.ejecutarSelectAll("proovedor");
        
        if(resultado!=null){

            for(int i=0; i<resultado.size(); i++){
                
                ArrayList vRowTempe = (ArrayList)resultado.get(i);
                proovedoresLista proovedor = new proovedoresLista();
               
                proovedor.setId(vRowTempe.get(0).toString());
                proovedor.setNombre(vRowTempe.get(1).toString());
                proovedor.setDireccion(vRowTempe.get(2).toString());
                proovedor.setTelefono(vRowTempe.get(3).toString());
               
                this.lista.add(proovedor);
            }   

        }
        
       }catch(Exception e){
           
            System.out.println(e);
            
       }
    }
    
    public void registro(){
        
        String tabla="proovedor";
        String datos=nombre+"|"+direccion+"|"+telefono;
        
        try{
        ConexionBD conexion =new ConexionBD();
        conexion.conectarMySQL();
        PreparedStatement stmt = null;//metodo
        String[] data = datos.split(Pattern.quote("|"));
        String signos="";
            for (int i = 0; i < data.length; i++) {
            signos+=",?";
            }
            String query = "INSERT INTO "+ tabla+ " VALUES(null"+
            signos        
            +")";
            stmt = conexion.conn.prepareStatement(query);
            stmt.setString(1,nombre);
            stmt.setString(2,direccion);
            stmt.setString(3,telefono);
            System.out.println("---------"+stmt);
        stmt.executeUpdate();
        conexion.desconectar();
      
        }catch(Throwable e){
            System.err.println(e);
        }
    }
    
}
