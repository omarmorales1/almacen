
package controlador;

import java.util.ArrayList;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import modelo.ConexionBD;
import net.bootsfaces.utils.FacesMessages;

/**
 *
 * @author Carlos Omar
 */

public class login {
   private String usuario;
   private String pass;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
   
    /**
     * Creates a new instance of registro
     */
    public login() {
    }
     public String usuarios() throws Exception{
        ConexionBD conexion = new ConexionBD();
        
        ArrayList resultado=conexion.ejecutarSelectWhere("usuarios", "user|password", usuario+"|"+pass);
        
        if(resultado.size()>0){
            
            ArrayList fila = (ArrayList)resultado.get(0);
            int tipo=Integer.parseInt((String) fila.get(7));
            switch(tipo){
                case 1:
                     System.out.println("almacen");
                break;
                case 2:
                    FacesContext context = javax.faces.context.FacesContext.getCurrentInstance();
                    HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
                    session.setAttribute("usuario", tipo);
                    
                   return "/faces/pedidos.xhtml?faces-redirect=true";
                case 3:
                    System.out.println("taller");
                break;
            }
                
            return "index.xhtml";
            
        }else{
            FacesContext.getCurrentInstance().addMessage(null, 
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Usuario y/o contraseña Incorrectos",""));
            return "";
        }
       
    }

}
