
package modelo;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 *
 * @author Judivell
 */
public class ConexionBD {
    
    // Librería de MySQL
    public String driver = null;

    // Nombre de la base de datos
    public String database = null;

    // Host
    public String hostname = null;

    // Puerto
    public String port = null;

    // Ruta de nuestra base de datos (desactivamos el uso de SSL con "?useSSL=false")
    public String url = null;

    // Nombre de usuario
    public String username = null;

    // Clave de usuario
    public String password = null;
    
    // variable de conexion
    public Connection conn = null;
    
    public ConexionBD() throws Exception{
        driver = "com.mysql.jdbc.Driver";
        database = "almacen";
        hostname = "localhost";
        port = "3306";
        url = "jdbc:mysql://" + hostname + ":" + port + "/" + database + "?useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        username = "root";
        password = "infierno";
    }
    
    //Realiza la conexion a la BD
    public boolean conectarMySQL() {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, username, password);
            return true;
        }catch(ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    ///Realiza la desconexion a la BD
   public void desconectar() throws Exception{
        conn.close();
    }
   
    //selecciona todos
    public void finalize()throws Exception, Throwable{
        try{
             conn.close();//cierra la conexion y los datos se vuelven nulos.Por privacida
             conn=null;
        }finally{
            super.finalize();
        }
    }
    
    ///Realiza una consulta a la BD y retorna un vector de resultados
    public synchronized ArrayList ejecutarSelectAll(String tabla)throws Exception{
        conectarMySQL();
        Statement stmt = null;//metodo
        ResultSet rset = null;//resultado de la consulta
        ArrayList vrset = null;
        ResultSetMetaData rsmd = null;
         ArrayList datos=new ArrayList<List>();
        int nNumCols=0;
        try{
            String psQuery="SELECT * FROM "+tabla;
            stmt = conn.createStatement(); ///creacion del statement/primero crear un statement, instanciar un objeto
            rset = stmt.executeQuery (psQuery); //ejecuta la consulta
            rsmd = rset.getMetaData();
            nNumCols = rsmd.getColumnCount();
            
            while (rset.next()) 
                { 
                    List<String> dato = new ArrayList<String>();
                    for (int i = 1; i <= nNumCols; i++) {
                        dato.add(rset.getString (i));
                    }
                    datos.add(dato);
                }
            
        }finally{
            if(rset != null){
                rset.close();
                if(stmt != null)
                    stmt.close();
            }
            rset = null;
            stmt = null;
            desconectar();
        }
        return datos;
    }
    
    //ejecuta una insercion de datos
    public synchronized boolean ejecutarInto(String tabla,String valores){
        try{
        conectarMySQL();
        PreparedStatement stmt = null;//metodo
        ResultSet rset = null;//resultado de la consulta 
        String[] data = valores.split(Pattern.quote("|"));
        String signos="";
            for (int i = 0; i < data.length; i++) {
            signos+=",?";
            }
            String query = "INSERT INTO "+ tabla+ " VALUES(null"+
            signos        
            +")";
            stmt = conn.prepareStatement(query);
            System.out.println(data.length);
            for (int i = 0; i < data.length; i++) {
                stmt.setString(i+1,data[i]);
            }
        stmt.executeUpdate();
        desconectar();
        return true;
        }catch(Throwable e){
            return false;
        }
       
    }
    
    //ejecuta una insercion de datos
    public synchronized boolean ejecutarUpdate(String tabla,String columnaAct,String valorAct,String columnaCond,String filaCond){
        try{
        conectarMySQL();
        PreparedStatement stmt = null;//metodo
        ResultSet rset = null;//resultado de la consulta 
        String[] columnas = columnaAct.split(Pattern.quote("|"));
        String[] valores = valorAct.split(Pattern.quote("|"));
        
        String signos= columnas[0]+" = '"+valores[0]+"'";
        if(columnas.length>1){
            for (int i = 0; i < columnas.length; i++) {
                signos+=","+columnas[i]+" = '"+valores[i]+"'";
            }
        }
        
    //*******************************************************************//
        
        String[] dataC = columnaCond.split(Pattern.quote("|"));
        String[] dataF = filaCond.split(Pattern.quote("|"));
        String columna="";
        String filas="";
        columna=dataC[0];
        filas=dataF[0];
        String condicional=columna+" = '"+filas+"'";
        if(dataC.length>1){
            for (int i = 1; i < dataC.length; i++) {
                condicional+= " AND "+dataC[i]+" = '"+dataF[i]+"'";
            }
        }
    
    //*****************************************************************
    
            String query = "UPDATE "+ tabla+ " SET "+signos+" WHERE "+condicional;
            System.out.println("+-+--+-+-+-+-+-+"+query);
            stmt = conn.prepareStatement(query);
                    
        stmt.executeUpdate();
        desconectar();
        return true;
        }catch(Throwable e){
            return false;
        }
       
    }
    
    //selecciona todos con condicional
    public synchronized ArrayList ejecutarSelectWhere(String tabla,String columnas,String fila)throws Exception{
        conectarMySQL();
        Statement stmt = null;//metodo
        ResultSet rset = null;//resultado de la consulta
        ArrayList vrset = null;
        ResultSetMetaData rsmd = null;
        ArrayList datos=new ArrayList<List>();
        
        String[] dataC = columnas.split(Pattern.quote("|"));
        String[] dataF = fila.split(Pattern.quote("|"));
        String columna="";
        String filas="";
        columna=dataC[0];
        filas=dataF[0];
        String condicional=columna+" = '"+filas+"'";
        if(dataC.length>1){
            for (int i = 1; i < dataC.length; i++) {
                condicional+= " AND "+dataC[i]+" = '"+dataF[i]+"'";
            }
        }
        int nNumCols=0;
        try{
            String psQuery="SELECT * FROM "+tabla+" WHERE "+condicional;
            stmt = conn.createStatement(); ///creacion del statement/primero crear un statement, instanciar un objeto
            rset = stmt.executeQuery (psQuery); //ejecuta la consulta
            rsmd = rset.getMetaData();
            nNumCols = rsmd.getColumnCount();
            
            while (rset.next()) 
                { 
                    List<String> dato = new ArrayList<String>();
                    for (int i = 1; i <= nNumCols; i++) {
                        dato.add(rset.getString (i));
                    }
                    datos.add(dato);
                }
        }finally{
            if(rset != null){
                rset.close();
                if(stmt != null)
                    stmt.close();
            }
            rset = null;
            stmt = null;
            desconectar();
        }
        return datos;
    }

    
}
